#!/bin/bash
rm -vf /usr/bin/openyoudao
rm -vf /usr/bin/install-openyoudao.sh
rm -rvf /usr/lib/openyoudao
rm -vf /usr/share/applications/openyoudao
rm -rvf /var/cache/openyoudao
rm -vf /usr/bin/uninstall-openyoudao.sh
